from tkinter import *
import tkinter as tk
from PIL import Image, ImageTk
import os
import mysql.connector

mydb = mysql.connector.connect(host="localhost", user="root", passwd="password", database="mydb")

my_cursor = mydb.cursor()

if mydb.is_connected:
    print("Success")
else:
    print("Fail")

def change_plan_e():
    i = 3
    my_cursor.execute("UPDATE IGNORE Members SET `Work Plan_Work_plan_ID`= `Work Plan_Work_plan_ID`-1")
    my_cursor.execute("SELECT * FROM  members WHERE Member_Fname=%s", (user_name,))
    for member in my_cursor:
        for j in range(1, 8):
            e = Label(text=member[j], )
            e.grid(row=i, column=1)
            i = i + 1
    i = 4
    Label(text="Current Workout", font=("Calibri 12 underline")).grid(row=2, column=3, columnspan=1)
    my_cursor.execute(
        "SELECT * FROM mydb.`Workout Schedule` WHERE mydb.`Workout Schedule`.`Work Plan_Work_plan_ID` =%s",
        (member[9],))
    Label(text="Leg Press, Leg Extension, Barbell Squats").grid(row=3, column=3)
    Label(text="Cable Flys, Bench Press', 'Cable Rows', 'Bench Dips").grid(row=5, column=3)
    Label(text="Lateral Raises, Overhead Press', 'Calf Raises', 'Reverse Crunches").grid(row=7, column=3)

    for att in my_cursor:
        for j in range(8, 9):
            e = Label(text=att[j], )
            e.grid(row=i, column=3)
            i = i + 2

def change_plan_h():
    i = 3
    my_cursor.execute("UPDATE IGNORE Members SET `Work Plan_Work_plan_ID`= `Work Plan_Work_plan_ID`+1")
    my_cursor.execute("SELECT * FROM  members WHERE Member_Fname=%s", (user_name,))
    for member in my_cursor:
        for j in range(1, 8):
            e = Label(text=member[j], )
            e.grid(row=i, column=1)
            i = i + 1
    i = 4
    Label(text="Current Workout", font=("Calibri 12 underline")).grid(row=2, column=3, columnspan=1)
    my_cursor.execute(
        "SELECT * FROM mydb.`Workout Schedule` WHERE mydb.`Workout Schedule`.`Work Plan_Work_plan_ID` =%s",
        (member[9],))
    Label(text="Leg Press, Leg Extension, Barbell Squats").grid(row=3, column=3)
    Label(text="Cable Flys, Bench Press', 'Cable Rows', 'Bench Dips").grid(row=5, column=3)
    Label(text="Lateral Raises, Overhead Press', 'Calf Raises', 'Reverse Crunches").grid(row=7, column=3)

    for att in my_cursor:
        for j in range(8, 9):
            e = Label(text=att[j], )
            e.grid(row=i, column=3)
            i = i + 2
def display():
    i = 3
    Label(text="Member Information", font=("Calibri 12 underline")).grid(row=2, column=0, columnspan=3)
    Label(text="First Name:").grid(row=3, column=0)
    Label(text="Last Name:").grid(row=4, column=0)
    Label(text="Address:").grid(row=5, column=0)
    Label(text="City:").grid(row=6, column=0)
    Label(text="State:").grid(row=7, column=0)
    Label(text="Zip Code:").grid(row=8, column=0)
    Label(text="Phone Number:").grid(row=9, column=0)
    my_cursor.execute("SELECT * FROM  members WHERE Member_Fname=%s", (user_name,))
    for member in my_cursor:
        for j in range(1,8):
            e = Label(text=member[j],)
            e.grid(row=i, column=1)
            i=i+1
    i = 4
    Label(text="Current Workout", font=("Calibri 12 underline")).grid(row=2, column=3, columnspan=1)
    my_cursor.execute("SELECT * FROM mydb.`Workout Schedule` WHERE mydb.`Workout Schedule`.`Work Plan_Work_plan_ID` =%s", (member[9],))
    Label(text="Leg Press, Leg Extension, Barbell Squats").grid(row=3,column=3)
    Label(text="Cable Flys, Bench Press', 'Cable Rows', 'Bench Dips").grid(row=5,column=3)
    Label(text="Lateral Raises, Overhead Press', 'Calf Raises', 'Reverse Crunches").grid(row=7,column=3)

    for att in my_cursor:
        for j in range(8,9):
            e = Label(text=att[j],)
            e.grid(row=i, column=3)
            i=i+2

# Designing window for member portal

def member_screen():
    global member_screen
    member_screen = tk.Tk()
    member_screen.geometry("1150x500")
    image = Image.open("dumbbell.png")
    resize_image = image.resize((150, 90))
    barbell = ImageTk.PhotoImage(resize_image)
    barbell_label1 = Label(member_screen, image=barbell)
    barbell_label1.grid(row=0, column=0)
    barbell_label1.image = barbell
    barbell_label2 = Label(member_screen, image=barbell)
    barbell_label2.grid(row=0, column=6, sticky='e')
    barbell_label2.image = barbell
    member_screen.title("Member Portal")
    Label(member_screen, text="GRIZZ FITNESS", font=("Calibri", 30), fg="lightgoldenrod4").grid(row=0, column=3)
    Label(text="", bg="lightgoldenrod4", width="150", height="1", font=("Calibri", 13)).grid(row=1, column=0, columnspan=12)
    display()
    Label(text="", bg="lightgoldenrod4", width="150", height="1", font=("Calibri", 13)).grid(column=0, columnspan=12)
    Label(text="©2022").grid(column=6)
    Button(member_screen, text="Easier Plan", width=10, height=1, bg="grey", command=change_plan_e).grid(row=5, column=5)
    Button(member_screen, text="Harder Plan", width=10, height=1, bg="grey", command=change_plan_h).grid(row=7, column=5)



# Designing window for registration

def register():
    global register_screen
    register_screen = Toplevel(main_screen)
    register_screen.title("Register")
    register_screen.geometry("300x250")

    global username
    global password
    global username_entry
    global password_entry
    username = StringVar()
    password = StringVar()

    Label(register_screen, text="Please enter details below", bg="grey").pack()
    Label(register_screen, text="").pack()
    username_lable = Label(register_screen, text="Username * ")
    username_lable.pack()
    username_entry = Entry(register_screen, textvariable=username)
    username_entry.pack()
    password_lable = Label(register_screen, text="Password * ")
    password_lable.pack()
    password_entry = Entry(register_screen, textvariable=password, show='*')
    password_entry.pack()
    Label(register_screen, text="").pack()
    Button(register_screen, text="Register", width=10, height=1, bg="grey", command=register_user).pack()


# Designing window for login

def login():
    global login_screen
    login_screen = Toplevel(main_screen)
    login_screen.title("Login")
    login_screen.geometry("300x250")
    Label(login_screen, text="Please enter details below to login").pack()
    Label(login_screen, text="").pack()

    global username_verify
    global password_verify

    username_verify = StringVar()
    password_verify = StringVar()

    global username_login_entry
    global password_login_entry

    Label(login_screen, text="Username * ").pack()
    username_login_entry = Entry(login_screen, textvariable=username_verify)
    username_login_entry.pack()
    Label(login_screen, text="").pack()
    Label(login_screen, text="Password * ").pack()
    password_login_entry = Entry(login_screen, textvariable=password_verify, show='*')
    password_login_entry.pack()
    Label(login_screen, text="").pack()
    Button(login_screen, text="Login", width=10, height=1, command=login_verify).pack()


# Implementing event on register button

def register_user():
    username_info = username.get()
    password_info = password.get()

    file = open(username_info, "w")
    file.write(username_info + "\n")
    file.write(password_info)
    file.close()

    username_entry.delete(0, END)
    password_entry.delete(0, END)

    Label(register_screen, text="Registration Success", fg="green", font=("calibri", 11)).pack()


# Implementing event on login button

def login_verify():
    global user_name
    username1 = username_verify.get()
    password1 = password_verify.get()
    username_login_entry.delete(0, END)
    password_login_entry.delete(0, END)

    list_of_files = os.listdir()
    if username1 in list_of_files:
        file1 = open(username1, "r")
        verify = file1.read().splitlines()
        user_name = username1
        if password1 in verify:
            delete_login()
            main_screen.destroy()
            member_screen()

        else:
            password_not_recognised()

    else:
        user_not_found()


# Designing popup for login invalid password

def password_not_recognised():
    global password_not_recog_screen
    password_not_recog_screen = Toplevel(login_screen)
    password_not_recog_screen.title("Success")
    password_not_recog_screen.geometry("150x100")
    Label(password_not_recog_screen, text="Invalid Password ").pack()
    Button(password_not_recog_screen, text="OK", command=delete_password_not_recognised).pack()


# Designing popup for user not found

def user_not_found():
    global user_not_found_screen
    user_not_found_screen = Toplevel(login_screen)
    user_not_found_screen.title("Success")
    user_not_found_screen.geometry("150x100")
    Label(user_not_found_screen, text="User Not Found").pack()
    Button(user_not_found_screen, text="OK", command=delete_user_not_found_screen).pack()


# Deleting popups

def delete_login():
    login_screen.destroy()


def delete_password_not_recognised():
    password_not_recog_screen.destroy()


def delete_user_not_found_screen():
    user_not_found_screen.destroy()


# Designing Main(first) window

def main_account_screen():
    global main_screen
    main_screen = tk.Tk()
    main_screen.geometry("410x300")
    image1 = Image.open("barbell.png")
    resize_image = image1.resize((90, 60))
    barbell = ImageTk.PhotoImage(resize_image)
    label1 = Label(image=barbell)
    label1.image = barbell
    label1.grid(row=0, column=0)
    label2 = Label(image=barbell)
    label2.image = barbell
    label2.grid(row=0, column=3)
    main_screen.title("Account Login")
    Label(text="Select Your Choice", bg="grey", width="40", height="2", font=("Calibri", 13)).grid(row=1, column=0,
                                                                                                    columnspan=4)
    Label(text="").grid(row=2, column=1)
    Button(text="Login", height="2", width="30", command=login).grid(row=3, column=1)
    Label(text="").grid(row=4, column=1)
    Button(text="Register", height="2", width="30", command=register).grid(row=5, column=1)
    main_screen.mainloop()


main_account_screen()






